package com.example.antivirusfirstscreen;

public class Child {

    private String name;
    private int timeLimit;
    private int usageTime;

    public Child() {
        // Default constructor required for calls to DataSnapshot.getValue(Child.class)
    }

    public Child(String name, int timeLimit, int usageTime) {
        this.name = name;
        this.timeLimit = timeLimit;
        this.usageTime = usageTime;
    }

    public String getName() {
        return name;
    }

    public int getTimeLimit() {
        return timeLimit;
    }

    public int getUsageTime() {
        return usageTime;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTimeLimit(int timeLimit) {
        this.timeLimit = timeLimit;
    }

    public void setUsageTime(int usageTime) {
        this.usageTime = usageTime;
    }
}
