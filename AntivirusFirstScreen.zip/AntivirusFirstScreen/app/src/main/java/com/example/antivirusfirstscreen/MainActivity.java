package com.example.antivirusfirstscreen;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private ImageButton enter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        enter = (ImageButton) findViewById(R.id.enter);
        enter.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {

                openfirstscreen();

            }

        });

    }

    public void openfirstscreen(){

        Intent i = new Intent(MainActivity.this, firstscreen.class);
        startActivity(i);

    }

}