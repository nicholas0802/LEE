package com.example.antivirusfirstscreen;

import android.app.Application;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

public class MyApplication extends Application {

    public void onCreate() {
        super.onCreate();

        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApplicationId("your-app-id") // Required for Analytics.
                .setApiKey("your-api-key") // Required for Auth.
                .setDatabaseUrl("https://your-database-url.firebaseio.com") // Required for RTDB.
                .setGcmSenderId("your-sender-id") // Required for FCM.
                .setProjectId("your-project-id")
                .build();

        FirebaseApp.initializeApp(this, options);
    }
}
