package com.example.antivirusfirstscreen;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.RemoteMessage;

import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class TrackingService extends Service {
    private DatabaseReference mDatabase;
    private String childPhone;
    private int usageTime;
    private Handler handler = new Handler();
    private Runnable runnable;

    @Override
    public void onCreate() {
        super.onCreate();
        mDatabase = FirebaseDatabase.getInstance().getReference();
        childPhone = "CHILD_PHONE_NUMBER"; // Replace with actual child phone number

        // Get initial values from Firebase
        mDatabase.child("children").child(childPhone).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Child child = task.getResult().getValue(Child.class);
                if (child != null) {
                    usageTime = child.getTimeLimit() * 3600; // Convert time limit from hours to seconds
                }
            }
        });

        // Runnable to update usage time every second
        runnable = new Runnable() {
            @Override
            public void run() {
                if (usageTime > 0) {
                    usageTime--;
                    mDatabase.child("children").child(childPhone).child("usageTime").setValue(usageTime);

                    if (usageTime == 0) {
                        sendNotification();
                    }

                    handler.postDelayed(this, 1000); // Run every 1000 milliseconds (1 second)
                } else {
                    stopSelf(); // Stop the service when the countdown reaches zero
                }
            }
        };
        handler.post(runnable);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(runnable);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void sendNotification() {
        Intent intent = new Intent(this, childmainscreen.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_ONE_SHOT);

        String channelId = "UsageNotification";
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Usage Time Over")
                .setContentText("Your usage time has ended.")
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Usage Notification", NotificationManager.IMPORTANCE_HIGH);
            manager.createNotificationChannel(channel);
        }

        manager.notify(0, builder.build());
    }
}