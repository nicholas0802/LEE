package com.example.antivirusfirstscreen;

import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class VirusScan extends AppCompatActivity {
    private List<String> detectedTrojanPackages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_virus_scan);

        Button scanButton = findViewById(R.id.scanButton);
        ListView resultsListView = findViewById(R.id.resultsListView);
        Button gobackbtn = findViewById(R.id.gobackbtn);

        scanButton.setOnClickListener(v -> scanForTrojans(resultsListView));
        gobackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(VirusScan.this,parentmainscreen.class);
                startActivity(i);

            }
        });

    }

    private void scanForTrojans(ListView resultsListView) {
        detectedTrojanPackages = new ArrayList<>();

        // Known Trojan package names (example list)
        Set<String> knownTrojanPackages = new HashSet<>();
        knownTrojanPackages.add("com.example.trojansample"); // Add actual known Trojan package names

        PackageManager packageManager = getPackageManager();
        List<ApplicationInfo> apps = packageManager.getInstalledApplications(0);
        for (ApplicationInfo app : apps) {
            if (knownTrojanPackages.contains(app.packageName)) {
                detectedTrojanPackages.add(app.packageName);
            }
        }

        if (detectedTrojanPackages.isEmpty()) {
            detectedTrojanPackages.add("No Trojans detected.");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text1, detectedTrojanPackages) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                TextView text1 = view.findViewById(android.R.id.text1);
                Button uninstallButton = new Button(VirusScan.this);
                uninstallButton.setText("Uninstall");

                String packageName = getItem(position);
                if (packageName.equals("No Trojans detected.")) {
                    uninstallButton.setVisibility(View.GONE);
                } else {
                    uninstallButton.setOnClickListener(v -> uninstallApp(packageName));
                }

                ((ViewGroup) view).addView(uninstallButton);
                text1.setText(packageName);
                return view;
            }
        };

        resultsListView.setAdapter(adapter);
    }

    private void uninstallApp(String packageName) {
        Intent intent = new Intent(Intent.ACTION_DELETE);
        intent.setData(Uri.parse("package:" + packageName));
        startActivity(intent);
    }
}