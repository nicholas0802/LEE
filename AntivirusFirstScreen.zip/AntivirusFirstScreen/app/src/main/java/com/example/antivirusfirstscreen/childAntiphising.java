package com.example.antivirusfirstscreen;

import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ProgressBar;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class childAntiphising extends AppCompatActivity {

    WebView web_view;
    EditText web_address_edit_text;
    ProgressBar progressbar;
    ImageButton back, forward, stop, refresh, home;
    Button go_button,mainscreenbtn;
    ArrayList<String> FlaggedURL = new ArrayList<String>();
    int token = 0;
    String loadURL = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child_antiphising);

            web_address_edit_text = (EditText) findViewById(R.id.web_address_edit_text);
            back = (ImageButton) findViewById(R.id.back);
            forward = (ImageButton) findViewById(R.id.forward);
            stop = (ImageButton) findViewById(R.id.stop);
            go_button = (Button)findViewById(R.id.go_button);
            mainscreenbtn = (Button)findViewById(R.id.mainscreenbtn1);
            refresh = (ImageButton) findViewById(R.id.refresh);
            home = (ImageButton) findViewById(R.id.home);
            progressbar = (ProgressBar) findViewById(R.id.progressbar);
            progressbar.setMax(100);
            progressbar.setVisibility(View.VISIBLE);
            web_view = (WebView) findViewById(R.id.web_view);

            BufferedReader reader = null;
            try {
                reader = new BufferedReader(
                        new InputStreamReader(getAssets().open("URList.txt"), "UTF-8"));
                String mLine;
                while ((mLine = reader.readLine()) != null) {
                    FlaggedURL.add(mLine);
                }
            } catch (IOException e) {
                Log.i("Read URL Error: ", String.valueOf(e));
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        Log.i("Read IO Error: ", String.valueOf(e));
                    }
                }
            }


            if (savedInstanceState != null) {
                web_view.restoreState(savedInstanceState);
            } else {
                web_view.getSettings().setJavaScriptEnabled(true);
                web_view.getSettings().setUseWideViewPort(true);
                web_view.getSettings().setLoadWithOverviewMode(true);
                web_view.getSettings().setSupportZoom(true);
                web_view.getSettings().setSupportMultipleWindows(true);
                web_view.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
                web_view.setBackgroundColor(Color.WHITE);

                web_view.setWebChromeClient(new WebChromeClient() {
                    @Override
                    public void onProgressChanged(WebView view, int newProgress) {
                        super.onProgressChanged(view, newProgress);
                        progressbar.setProgress(newProgress);
                        if (newProgress < 100 && progressbar.getVisibility() == ProgressBar.GONE) {
                            progressbar.setVisibility(ProgressBar.VISIBLE);
                        }
                        if (newProgress == 100) {
                            progressbar.setVisibility(ProgressBar.GONE);
                        }else{
                            progressbar.setVisibility(ProgressBar.VISIBLE);
                        }
                    }
                });
            }

            web_view.setWebViewClient(new MyWebViewClient());
            go_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    token = 0;
                    String tempX = web_address_edit_text.getText().toString();
                    if (tempX.substring(0,8).equals("https://")){
                        loadURL = web_address_edit_text.getText().toString();
                    } else if (tempX.substring(0,7).equals("http://")) {
                        loadURL = "https://" + (web_address_edit_text.getText().toString()).substring(7,(web_address_edit_text.getText().toString()).length());
                        makeText(childAntiphising.this,"auto changed to HTTPS", LENGTH_SHORT).show();
                    } else {
                        loadURL = "https://" + web_address_edit_text.getText().toString();
                    }
                    for (int i = 0; i < FlaggedURL.size() ; i ++){
                        if (loadURL.equals(FlaggedURL.get(i))){
                            token = 1;
                        }
                    }
                    try {
                        if(!NetworkState.connectionAvailable(childAntiphising.this)){
                            makeText(childAntiphising.this, R.string.app_name, LENGTH_SHORT).show();
                        }else {
                            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                            inputMethodManager.hideSoftInputFromWindow(web_address_edit_text.getWindowToken(), 0);
                            if (token <= 0){
                                web_view.loadUrl(loadURL);
                                web_address_edit_text.setText("");
                            } else {
                                new AlertDialog.Builder(childAntiphising.this)
                                        .setTitle("Malicious Link Detected")
                                        .setMessage("Are you sure you want to continue to this website?")
                                        // Specifying a listener allows you to take an action before dismissing the dialog.
                                        // The dialog is automatically dismissed when a dialog button is clicked.
                                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int which) {
                                                web_view.loadUrl("https://" + web_address_edit_text.getText().toString());
                                                web_address_edit_text.setText("");
                                            }
                                        })

                                        // A null listener allows the button to dismiss the dialog and take no further action.
                                        .setNegativeButton(android.R.string.no, null)
                                        .setIcon(android.R.drawable.ic_dialog_alert)
                                        .show();
                            }
                        }

                    }catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });

            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (web_view.canGoBack()) {
                        web_view.goBack();
                    }
                }
            });
            forward.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (web_view.canGoForward()) {
                        web_view.goForward();
                    }
                }
            });

            stop.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    web_view.stopLoading();
                }
            });

            refresh.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    web_view.reload();
                }
            });
            home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    web_view.loadUrl("https://www.google.com");
                }
            });

            mainscreenbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent i = new Intent(childAntiphising.this,childmainscreen.class);
                    startActivity(i);

                }
            });
        }


    }