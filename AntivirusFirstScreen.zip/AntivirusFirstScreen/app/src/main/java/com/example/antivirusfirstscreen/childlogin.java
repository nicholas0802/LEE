package com.example.antivirusfirstscreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class childlogin extends AppCompatActivity {

    private Button loginbtn,childSignUp;

    private EditText nophonechild,passwordchild;

    private ImageButton undo;

    private CheckBox swpass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_childlogin);

        childSignUp =  findViewById(R.id.childSignUp);
        loginbtn = findViewById(R.id.loginbtn);
        nophonechild = findViewById(R.id.nophonechild);
        passwordchild = findViewById(R.id.passwordchild);
        swpass = findViewById(R.id.swpass);

        childSignUp.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                openchildregister();
            }

        });

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!validateNophone()|!validatePassword()){

                }

                else{

                    checkUser();

                }

            }
        });

        swpass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){

                    passwordchild.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                }

                else{

                    passwordchild.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

    }

    public void openchildregister() {

        Intent i = new Intent(childlogin.this, childregister.class);
        startActivity(i);


    }

    public boolean validateNophone(){

        String value =nophonechild.getText().toString();
        if(value.isEmpty()){

            nophonechild.setError("Cannot be empty");
            return false;

        }
        else{

            nophonechild.setError(null);
            return true;

        }
    }

    public boolean validatePassword(){

        String value =passwordchild.getText().toString();
        if(value.isEmpty()){

            passwordchild.setError("Cannot be empty");
            return false;

        }
        else{

            passwordchild.setError(null);
            return true;

        }
    }

    public void checkUser(){

        String userphone = nophonechild.getText().toString().trim();
        String userpassword = passwordchild.getText().toString().trim();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://antivirusfirstscreen-default-rtdb.firebaseio.com/");
        Query checkDatabase = reference;

        checkDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.hasChild(userphone)){

                    String passFrDB = snapshot.child(userphone).child("password").getValue(String.class);

                    if(passFrDB.equals(userpassword)){

                        nophonechild.setError(null);
                        Intent intent = new Intent(childlogin.this,childmainscreen.class);
                        startActivity(intent);

                    }

                    else{

                        passwordchild.setError("Invalid Credentials");
                        passwordchild.requestFocus();
                    }

                }

                else{

                    nophonechild.setError("No.phone does not exist");
                    nophonechild.requestFocus();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}




