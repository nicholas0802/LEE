package com.example.antivirusfirstscreen;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

public class childmainscreen extends AppCompatActivity {

    private ProgressDialog progressDialog;
    private Button clearbtnchild,boosterbtnchild,antiphisingchildbtn,childScanbtn;
    TextView textView;
    private TextView alertTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_childmainscreen);

        clearbtnchild=findViewById(R.id.clearbtnchild);
        boosterbtnchild=findViewById(R.id.boosterbtnchild);
        antiphisingchildbtn=findViewById(R.id.antiphisingbtnchild);
        childScanbtn=findViewById(R.id.childScanbtn);
        textView = findViewById(R.id.textView);
        alertTextView = (TextView) findViewById(R.id.AlertTextView);

// Receive the time limit from parental control
        int timeLimitInHours = getIntent().getIntExtra("timeLimit", 0);

        clearbtnchild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cleanJunkFiles();
            }
        });

        boosterbtnchild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boostDevice();

            }
        });

        antiphisingchildbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(childmainscreen.this,childAntiphising.class);
                startActivity(i);

            }
        });

        childScanbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i2 = new Intent(childmainscreen.this,ChildVirusScan.class);
                startActivity(i2);

            }
        });

        Intent serviceIntent = new Intent(this, TrackingService.class);
        startService(serviceIntent);

        CountDownTimer start = new CountDownTimer(timeLimitInHours * 3600000, 1000) {
            public void onTick(long millisUntilFinished) {
                // Used for formatting digit to be in 2 digits only
                NumberFormat f = new DecimalFormat("00");
                long hour = (millisUntilFinished / 3600000) % 24;
                long min = (millisUntilFinished / 60000) % 60;
                long sec = (millisUntilFinished / 1000) % 60;
                textView.setText(f.format(hour) + ":" + f.format(min) + ":" + f.format(sec));
            }

            // When the task is over it will print 00:00:00 there
            public void onFinish() {
                textView.setText("00:00:00");

                AlertDialog.Builder builder = new AlertDialog.Builder(childmainscreen.this);

                builder.setCancelable(true);
                builder.setTitle("Time up!!!");
                builder.setMessage("Please give back your phone to your parent");

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        alertTextView.setVisibility(View.VISIBLE);
                    }
                });
                builder.show();
            }


        }.start();
    }

    //clean junk part
    private void cleanJunkFiles() {
        progressDialog = new ProgressDialog(childmainscreen.this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle("Cleaning Junk Files");
        progressDialog.setMessage("Please wait...");
        progressDialog.setMax(100);
        progressDialog.setProgress(0);
        progressDialog.setCancelable(false);
        progressDialog.show();

        new CleanJunkFileTask().execute();
    }

    private class CleanJunkFileTask extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            // Clean cache files
            deleteFiles(getCacheDir());
            publishProgress(33);

            // Clean residual files
            deleteFiles(new File(getFilesDir().getParent() + "/databases"));
            publishProgress(66);

            // Clean temp files
            deleteFiles(Environment.getExternalStorageDirectory());
            publishProgress(100);

            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressDialog.setProgress(values[0]);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            progressDialog.dismiss();
            Toast.makeText(childmainscreen.this, "Junk cleaned successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void deleteFiles(File directory) {
        if (directory != null && directory.exists()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (file.isDirectory()) {
                        deleteFiles(file);
                    } else {
                        file.delete();
                    }
                }
            }
        }
    }

    //boster part
    private void boostDevice() {
        new BoostTask().execute();
    }

    private class BoostTask extends AsyncTask<Void, Integer, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Show a progress dialog or some indication to the user
            Toast.makeText(childmainscreen.this, "Boosting device...", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            // Clear background tasks
            clearBackgroundTasks();
            publishProgress(50); // Update progress

            // Free up RAM
            // Note: Directly forcing garbage collection might not be very effective
            // For demonstration purposes, let's simulate a delay
            try {
                Thread.sleep(2000); // Simulate a delay of 2 seconds
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            // Update UI with the progress
            Toast.makeText(childmainscreen.this, "Progress: " + values[0] + "%", Toast.LENGTH_SHORT).show();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            // Hide the progress dialog or update UI accordingly
            Toast.makeText(childmainscreen.this, "Device boosted successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    private void clearBackgroundTasks() {
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        if (activityManager != null) {
            List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = activityManager.getRunningAppProcesses();
            if (runningAppProcesses != null) {
                for (ActivityManager.RunningAppProcessInfo processInfo : runningAppProcesses) {
                    // Kill unnecessary background processes
                    // Be careful not to kill critical system processes
                    activityManager.killBackgroundProcesses(processInfo.processName);
                }
            }
        }
    }

}