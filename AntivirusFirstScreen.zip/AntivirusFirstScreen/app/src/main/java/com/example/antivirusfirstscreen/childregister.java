package com.example.antivirusfirstscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class childregister extends AppCompatActivity {

        private EditText etfullname2,etnophone2,etpassword2,rePassword2;
        private TextView tvstatus2;
        private ImageButton exit2;
        private Button registerbtn2;
        FirebaseDatabase db;
        DatabaseReference rf;
        private CheckBox showpassbtn2;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_childregister);
            etfullname2 = findViewById(R.id.etfullname2);
            etnophone2 = findViewById(R.id.etnoPhone2);
            etpassword2 = findViewById(R.id.etpasswordlgn2);
            rePassword2 = findViewById(R.id.rePassword2);
            exit2 = findViewById(R.id.exit2);
            registerbtn2 = findViewById(R.id.registerbtn2);
            showpassbtn2 = findViewById(R.id.showpassbtn2);

            showpassbtn2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){

                        etpassword2.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        rePassword2.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                    }

                    else{

                        etpassword2.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        rePassword2.setTransformationMethod(PasswordTransformationMethod.getInstance());

                    }
                }
            });

            exit2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent2 = new Intent(childregister.this, childlogin.class);
                    startActivity(intent2);
                    finish();

                }


            });


            registerbtn2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    db = FirebaseDatabase.getInstance();
                    rf = db.getReferenceFromUrl("https://antivirusfirstscreen-default-rtdb.firebaseio.com/");

                    String fullname,nophone,password,repassword;
                    fullname = String.valueOf(etfullname2.getText());
                    nophone = String.valueOf(etnophone2.getText());
                    password = String.valueOf(etpassword2.getText());
                    repassword = String.valueOf(rePassword2.getText());




                    if(TextUtils.isEmpty(fullname)){

                        Toast.makeText(childregister.this,"Enter Your Name",Toast.LENGTH_SHORT).show();
                        return;

                    } else if (TextUtils.isEmpty(nophone)) {

                        Toast.makeText(childregister.this,"Enter Your Nophone",Toast.LENGTH_SHORT).show();
                        return;

                    } else if (TextUtils.isEmpty(password)){

                        Toast.makeText(childregister.this,"Enter Your password",Toast.LENGTH_SHORT).show();
                        return;

                    } else if (TextUtils.isEmpty(repassword)){

                        Toast.makeText(childregister.this,"Your retype password cannot empty",Toast.LENGTH_SHORT).show();
                        return;

                    } else if (!password.equals(repassword)) {

                        Toast.makeText(childregister.this,"Your password is wrong",Toast.LENGTH_SHORT).show();
                        return;

                    }

                    Helperclass helperclass = new Helperclass(fullname,nophone,password,repassword);
                    rf.child(nophone).setValue(helperclass);

                    Toast.makeText(childregister.this,"You have signup successfully!",Toast.LENGTH_SHORT).show();
                    Intent intent3 = new Intent(childregister.this,childlogin.class);
                    startActivity(intent3);

                }
            });

        }
    }
