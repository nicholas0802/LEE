package com.example.antivirusfirstscreen;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class parentalControl extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private EditText nophoneField, childNameField, timeLimitField;
    private Button addChildButton, setTimeLimitButton, backbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parental_control);


        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        nophoneField = findViewById(R.id.nophone);
        childNameField = findViewById(R.id.childName);
        timeLimitField = findViewById(R.id.timeLimit);

        addChildButton = findViewById(R.id.addChildButton);
        setTimeLimitButton = findViewById(R.id.setTimeLimitButton);
        backbtn = findViewById(R.id.backbtn);

        addChildButton.setOnClickListener(view -> addChild());
        setTimeLimitButton.setOnClickListener(view -> setTimeLimit());

        // Check if user is signed in (non-null) and update UI accordingly
        FirebaseUser currentUser = mAuth.getCurrentUser();

        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent I = new Intent(parentalControl.this, parentmainscreen.class);
                startActivity(I);

            }
        });

    }

    private void addChild() {
        String nophone = nophoneField.getText().toString().trim();
        String childName = childNameField.getText().toString().trim();

        if (TextUtils.isEmpty(nophone) || TextUtils.isEmpty(childName)) {
            Toast.makeText(this, "No phone and child name must not be empty.", Toast.LENGTH_SHORT).show();
            return;
        }

        Child child = new Child(childName, 1, 0); // Default time limit of 1 hour and initial usage time
        mDatabase.child("children").child(nophone).setValue(child)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(parentalControl.this, "Child added successfully.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(parentalControl.this, "Failed to add child.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void setTimeLimit() {
        String nophone = nophoneField.getText().toString().trim();
        String timeLimitStr = timeLimitField.getText().toString().trim();

        if (TextUtils.isEmpty(nophone) || TextUtils.isEmpty(timeLimitStr)) {
            Toast.makeText(this, "Phone number and time limit must not be empty.", Toast.LENGTH_SHORT).show();
            return;
        }

        int timeLimitInHours;
        try {
            timeLimitInHours = Integer.parseInt(timeLimitStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid time limit format.", Toast.LENGTH_SHORT).show();
            return;
        }

        mDatabase.child("children").child(nophone).child("timeLimit").setValue(timeLimitInHours)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(parentalControl.this, "Time limit set successfully.", Toast.LENGTH_SHORT).show();

                        // Pass the time limit to parent main screen
                        Intent intent = new Intent(parentalControl.this, parentmainscreen.class);
                        intent.putExtra("timeLimit", timeLimitInHours);
                        startActivity(intent);
                    } else {
                        Toast.makeText(parentalControl.this, "Failed to set time limit.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
