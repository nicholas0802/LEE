package com.example.antivirusfirstscreen;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class parentlogin extends AppCompatActivity {
    private EditText etphone,etpassword;
    private Button parentSignup, loginbtn;

    private ImageButton undo;

    private CheckBox swpass;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_parentlogin);
        parentSignup = findViewById(R.id.parentSignup);
        undo = findViewById(R.id.undo);
        loginbtn = findViewById(R.id.loginbtn);
        swpass = findViewById(R.id.swpass);
        etphone = findViewById(R.id.etphone);
        etpassword = findViewById(R.id.etpassword);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               if(!validateNophone()|!validatePassword()){

               }

               else{

                   checkUser();

               }

            }
        });

        parentSignup.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                openparentSignup();

            }
        });

        undo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openparentRegister();

            }
        });

        swpass.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){

                    etpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                }

                else{

                    etpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

    }

    public void openparentRegister(){

        Intent intent2 = new Intent(parentlogin.this, firstscreen.class);
        startActivity(intent2);

    }

    public void openparentSignup(){

        Intent intent3 = new Intent(parentlogin.this, parentregister.class);
        startActivity(intent3);

    }

    public boolean validateNophone(){

        String value =etphone.getText().toString();
        if(value.isEmpty()){

            etphone.setError("Cannot be empty");
            return false;

        }
        else{

            etphone.setError(null);
            return true;

        }
    }

    public boolean validatePassword(){

        String value =etpassword.getText().toString();
        if(value.isEmpty()){

            etpassword.setError("Cannot be empty");
            return false;

        }
        else{

            etpassword.setError(null);
            return true;

        }
    }

    public void checkUser(){

        String userphone = etphone.getText().toString().trim();
        String userpassword = etpassword.getText().toString().trim();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReferenceFromUrl("https://antivirusfirstscreen-default-rtdb.firebaseio.com/");
        Query checkDatabase = reference;

        checkDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange( DataSnapshot snapshot) {
                if(snapshot.hasChild(userphone)){

                    String passFrDB = snapshot.child(userphone).child("password").getValue(String.class);

                    if(passFrDB.equals(userpassword)){

                       etphone.setError(null);
                       Intent intent = new Intent(parentlogin.this,parentmainscreen.class);
                       startActivity(intent);

                    }

                    else{

                        etpassword.setError("Invalid Credentials");
                        etpassword.requestFocus();

                    }

                }

                else{

                    etphone.setError("No.phone does not exist");
                    etphone.requestFocus();

                }
            }

            @Override
            public void onCancelled( DatabaseError error) {

            }
        });

    }
}