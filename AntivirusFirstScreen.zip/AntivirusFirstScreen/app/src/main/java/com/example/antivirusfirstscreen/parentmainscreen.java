package com.example.antivirusfirstscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;
import java.util.List;

public class parentmainscreen extends AppCompatActivity {

    private ProgressDialog progressDialog;
    private Button clearbtn, boosterbtn, antiphisingbtn,parentalctrlbtn,scanbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parentmainscreen);
        clearbtn = findViewById(R.id.clearbtn);
        boosterbtn = findViewById(R.id.boosterbtn);
        antiphisingbtn = (Button) findViewById(R.id.antiphisingbtn);
        parentalctrlbtn = (Button) findViewById(R.id.parentalctrlbtn);
        scanbtn = (Button) findViewById(R.id.scanbtn) ;

        clearbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                cleanJunkFiles();

            }
        });

        boosterbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boostDevice();

            }
        });

        antiphisingbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openAntiphising();

            }

        });

        parentalctrlbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openParentalctrl();

            }
        });

        scanbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i3 = new Intent(parentmainscreen.this,VirusScan.class);
                startActivity(i3);

            }
        });

        int timeLimitInHours = getIntent().getIntExtra("timeLimit", 0);
        if (timeLimitInHours > 0) {
            long timeLimitInMillis = timeLimitInHours * 3600000;

            new CountDownTimer(timeLimitInMillis, 1000) {
                public void onTick(long millisUntilFinished) {
                    // Update UI if necessary
                }

                public void onFinish() {
                    // When the task is over, start the child main screen
                    Intent intent = new Intent(parentmainscreen.this, childmainscreen.class);
                    intent.putExtra("timeLimit", timeLimitInHours);
                    startActivity(intent);
                }
            }.start();
        }
    }



    public void openAntiphising(){

        Intent i = new Intent(parentmainscreen.this,parentAntiphising.class);
        startActivity(i);

    }

    public void openParentalctrl(){

        Intent i2 = new Intent(parentmainscreen.this,parentalControl.class);
        startActivity(i2);

    }



        //clean junk part
        private void cleanJunkFiles () {
            progressDialog = new ProgressDialog(parentmainscreen.this);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            progressDialog.setTitle("Cleaning Junk Files");
            progressDialog.setMessage("Please wait...");
            progressDialog.setMax(100);
            progressDialog.setProgress(0);
            progressDialog.setCancelable(false);
            progressDialog.show();

            new CleanJunkFilesTask().execute();
        }

        public class CleanJunkFilesTask extends AsyncTask<Void, Integer, Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                // Clean cache files
                deleteFiles(getCacheDir());
                publishProgress(33);

                // Clean residual files
                deleteFiles(new File(getFilesDir().getParent() + "/databases"));
                publishProgress(66);

                // Clean temp files
                deleteFiles(Environment.getExternalStorageDirectory());
                publishProgress(100);

                return null;
            }

            @Override
            protected void onProgressUpdate(Integer... values) {
                super.onProgressUpdate(values);
                progressDialog.setProgress(values[0]);
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                progressDialog.dismiss();
                Toast.makeText(parentmainscreen.this, "Junk cleaned successfully!", Toast.LENGTH_SHORT).show();
            }
        }

        private void deleteFiles (File directory){
            if (directory != null && directory.exists()) {
                File[] files = directory.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.isDirectory()) {
                            deleteFiles(file);
                        } else {
                            file.delete();
                        }
                    }
                }
            }
        }

        //boster part
        public void boostDevice () {
            new BoostTask().execute();
        }

        private class BoostTask extends AsyncTask<Void, Integer, Void> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                // Show a progress dialog or some indication to the user
                Toast.makeText(parentmainscreen.this, "Boosting device...", Toast.LENGTH_SHORT).show();
            }

            @Override
            protected Void doInBackground(Void... voids) {
                // Clear background tasks
                clearBackgroundTasks();
                publishProgress(50); // Update progress

                // Free up RAM
                // Note: Directly forcing garbage collection might not be very effective
                // For demonstration purposes, let's simulate a delay
                try {
                    Thread.sleep(2000); // Simulate a delay of 2 seconds
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                return null;
            }

            @Override
            protected void onProgressUpdate(Integer... values) {
                super.onProgressUpdate(values);
                // Update UI with the progress
                Toast.makeText(parentmainscreen.this, "Progress: " + values[0] + "%", Toast.LENGTH_SHORT).show();
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                // Hide the progress dialog or update UI accordingly
                Toast.makeText(parentmainscreen.this, "Device boosted successfully!", Toast.LENGTH_SHORT).show();
            }
        }

        private void clearBackgroundTasks () {
            ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (activityManager != null) {
                List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = activityManager.getRunningAppProcesses();
                if (runningAppProcesses != null) {
                    for (ActivityManager.RunningAppProcessInfo processInfo : runningAppProcesses) {
                        // Kill unnecessary background processes
                        // Be careful not to kill critical system processes
                        activityManager.killBackgroundProcesses(processInfo.processName);
                    }
                }
            }
        }


    }



