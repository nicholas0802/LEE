package com.example.antivirusfirstscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class parentregister extends AppCompatActivity {

    private EditText etfullname,etnophone,etpassword,rePassword;
    private TextView tvstatus;
    private ImageButton exit;
    private Button registerbtn;
    FirebaseDatabase db;
    DatabaseReference rf;
    private CheckBox showpassbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parentregister);
        etfullname = findViewById(R.id.etfullname);
        etnophone = findViewById(R.id.etnoPhone);
        etpassword = findViewById(R.id.etpasswordlgn);
        rePassword = findViewById(R.id.rePassword);
        exit = findViewById(R.id.exit);
        registerbtn = findViewById(R.id.registerbtn);
        showpassbtn = findViewById(R.id.showpassbtn);

        showpassbtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){

                    etpassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    rePassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                }

                else{

                    etpassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    rePassword.setTransformationMethod(PasswordTransformationMethod.getInstance());

                }
            }
        });

                exit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent2 = new Intent(parentregister.this, parentlogin.class);
                        startActivity(intent2);
                        finish();

                    }


                });


        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                db = FirebaseDatabase.getInstance();
                rf = db.getReferenceFromUrl("https://antivirusfirstscreen-default-rtdb.firebaseio.com/");

                 String fullname,nophone,password,repassword;
                 fullname = String.valueOf(etfullname.getText());
                 nophone = String.valueOf(etnophone.getText());
                 password = String.valueOf(etpassword.getText());
                 repassword = String.valueOf(rePassword.getText());




                 if(TextUtils.isEmpty(fullname)){

                     Toast.makeText(parentregister.this,"Enter Your Name",Toast.LENGTH_SHORT).show();
                     return;

                 } else if (TextUtils.isEmpty(nophone)) {

                     Toast.makeText(parentregister.this,"Enter Your Nophone",Toast.LENGTH_SHORT).show();
                     return;

                 } else if (TextUtils.isEmpty(password)){

                     Toast.makeText(parentregister.this,"Enter Your password",Toast.LENGTH_SHORT).show();
                     return;

                 } else if (TextUtils.isEmpty(repassword)){

                     Toast.makeText(parentregister.this,"Your retype password cannot empty",Toast.LENGTH_SHORT).show();
                     return;

                 } else if (!password.equals(repassword)) {

                     Toast.makeText(parentregister.this,"Your password is wrong",Toast.LENGTH_SHORT).show();
                     return;

                 }

                 Helperclass helperclass = new Helperclass(fullname,nophone,password,repassword);
                 rf.child(nophone).setValue(helperclass);

                 Toast.makeText(parentregister.this,"You have signup successfully!",Toast.LENGTH_SHORT).show();
                 Intent intent3 = new Intent(parentregister.this,parentlogin.class);
                 startActivity(intent3);


            }
        });

    }

    }

